﻿namespace MyWebApplication.Models.CatViewModels
{
    public class CatDetailsViewModel
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
    }
}