﻿$(document).ready(function() {
    $("#catLinkImage").animate({ left: "-90px" }, 6000);
});